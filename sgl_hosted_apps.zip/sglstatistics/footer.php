<!-- 
Created by: Siddharth Choksi in May 2010
This file provides the footer for all files related to the librarian-side 
-->
<br>
   </td>
  </tr>
</table><script type="text/javascript">
<!--
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgDown:"SpryAssets/SpryMenuBarDownHover.gif", imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
//-->
</script>
</body>
</html>
