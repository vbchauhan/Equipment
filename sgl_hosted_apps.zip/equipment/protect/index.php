<?php
	header("Location: /"); // re-direct to root of website.
	exit;
?>
