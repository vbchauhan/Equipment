<?PHP
$mysql_server="LOCALHOST";
$mysql_db="lenditdb";
$mysql_user="root";
$mysql_password="";
?>
