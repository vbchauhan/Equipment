<IMG BORDER="0" SRC="<?PHP print dirname($_SERVER['PHP_SELF']);?>/barcode39.php?bcdata=ABCD1235">
