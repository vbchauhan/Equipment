<!-- 
Created by: Siddharth Choksi in May 2010
Code snippet for catalog search. 
-->
<p align="center">
<form name="customsearch" action="http://catalog.umd.edu/cgi-bin/direct" target="_blank">
<strong>Search the Priddy Library catalog for book information: </strong>
<select name="searchtype">
<option value="F1_WRD">word/s anywhere</option>
<option value="SCAN_TTL">title beginning with</option>
<option value="F1_WTI">title word/s</option>
<option value="F1_WSU">subject word/s</option>
<option value="SCAN_LCI">call number</option>
</select>
<input type="text" name="searchrequest">
<input type="hidden" value="CP" name="base">

<input type="image" alt="search catalog" src="http://catalog.umd.edu/aleph/u18_1/alephe/www_f_eng/icon/search.gif" border="0" align="top">
</form>

</p>

